# CFX-Bypass

**For the people who are having problems.**  

Most likely not going to personally help you but you can ask other users about it here.
https://discord.gg/Db7BUuv9Zv

**What's the purpose of this?**

Program blocks the outbounding and inbounding calls from adhesive so they won't get to check your hwid from their auth server. Basically allows you to play FiveM on hwid banned computers.

**How to use:**
1. Clean Traces
2. Enable Bypass
3. Log in to new rockstar account without ban. The account must be unused, because fivem is banning the new accounts if your opening it without the bypass with hwid banned computer.
4. Try joining server if it returns error, then disable the bypass and try joining the server. 
5. NOTE: Don't ever open FiveM without the bypass. Otherwise they will ban your new rockstar account for using it in hwid banned computer.
6. IMPORTANT: Enable the bypass before u leave server so "Destroy" call won't be sent to fivem when you leave server. It contains your hwid + ROS

**Current status?**

Seems to be working 14.1.2022
